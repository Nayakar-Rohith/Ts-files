export default class List{
    _id: string;
    title: string;
    password: string;
}