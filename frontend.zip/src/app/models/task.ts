export default class Task{
    _id: string;
    title: string;
    _listId: string;
    completed: boolean;
    notes:string;
    progress:string;
    deadline: string;
    submittime: boolean;
}